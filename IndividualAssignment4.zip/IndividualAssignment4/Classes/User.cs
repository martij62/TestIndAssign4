﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;

namespace IndividualAssignment4
{
    [Activity(Label = "IndividualAssignment4", MainLauncher = true)]
    public class User : Activity
    {

        EditText txtUsername;
        EditText txtPassword;
        Button btnLogin;
        string Text;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.User);

            txtUsername = FindViewById<EditText>(Resource.Id.txtUsername);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            btnLogin = FindViewById<Button>(Resource.Id.btnLogin);

            btnLogin.Click += BtnLogin_Click;
            string Text = txtUsername.ToString();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (Text.Equals("admin"))
            {
                StartActivity(typeof(Account));
            }
        }
    }
}

